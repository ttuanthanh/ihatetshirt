{!! $content !!}

