@extends($template)

@section('content')


{!! $info->post_content !!}

@endsection

@section('style')

@stop

@section('plugin_script') 
@stop

@section('script')
@stop
