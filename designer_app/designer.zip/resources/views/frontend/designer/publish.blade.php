<div class="form-content">
    <div class="text-center">
        <h4 class="sbold uppercase margin-top-40 margin-bottom-20">Thank you for using shirt designer studio</h4>
        <p>However we would need you to<br> <b>SAVE</b> your artwork to get prices</p>
    </div>

    <div class="text-center margin-top-40">

        <a class="btn btn-green btn-lg btn-publish btn-block" href="javascript::void(0)">Save</a>    

        <p class="uppercase sbold margin-top-30">Share your work on social media</p>
    </div>

    <div class="socicons text-center margin-top-20">
        <a href="#" class="socicon-btn socicon-twitter tooltips" data-original-title="Twitter" onclick="shareOnTwitter()"></a>

        <a href="#" class="socicon-btn socicon-facebook tooltips" data-original-title="Facebook" onclick="shareOnFacebook()"></a>

        <a href="#" class="socicon-btn socicon-google tooltips" data-original-title="Google" onclick="shareOnGooglePlus()"></a>
        <a href="#" class="socicon-btn socicon-pinterest tooltips" data-original-title="Pinterest" onclick="shareOnPinterest()"></a>

    </div>
</div>

