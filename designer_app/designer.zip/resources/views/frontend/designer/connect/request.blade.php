<form class="form-horizontal" role="form">
    <div class="form-body">

    	<h4>Please leave your information so we can connect you with a graphic designer!</h4>

		<h5>Name</h5>
		<input type="text" class="form-control" placeholder="">

		<h5>Phone</h5>
		<input type="text" class="form-control" placeholder="">

		<h5>Email</h5>
		<input type="text" class="form-control" placeholder="">

		<h5>Message</h5>
		<textarea class="form-control" placeholder="" rows="5"></textarea>

		<div class="margin-top-20">
            <button type="submit" class="btn green"><i class="fa fa-send"></i> Submit</button>		
		</div>

	</div>
</form>  