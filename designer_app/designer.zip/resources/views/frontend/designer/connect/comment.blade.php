<form class="form-horizontal" role="form">
<div class="form-content">
    	<p>For special instructions leave a comment on your artwork. Keep in mind that we will have a professional clean up your artwork and send you a FINAL proof  before printing.</p>

		<textarea id="comment" class="form-control" placeholder="Leave your comment here ..." rows="5"></textarea>	
</div>
</form>  