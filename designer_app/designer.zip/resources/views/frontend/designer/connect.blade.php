<div class="tab-pane" id="design_comment">
@include('frontend.designer.connect.comment')
</div>