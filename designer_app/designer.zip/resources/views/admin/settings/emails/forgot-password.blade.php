<h5 class="sbold">Shortcodes :</h5>

<table class="table table-bordered">
<thead>
    <tr>
        <th>Code</th>
        <th>Description</th>
    </tr>
</thead>
<tr>
    <td>{firstname}</td>
    <td>First Name</td>
</tr>
<tr>
    <td>{lastname}</td>
    <td>Last Name</td>
</tr>
<tr>
    <td>{email}</td>
    <td>Email Address</td>
</tr>
<tr>
    <td>{date}</td>
    <td>Date Requested</td>
</tr>
<tr>
    <td>{change_password_url}</td>
    <td>Change password URL</td>
</tr>
</table>