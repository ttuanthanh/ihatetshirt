<h5 class="sbold">Shortcodes :</h5>

<table class="table table-bordered">
<thead>
    <tr>
        <th>Code</th>
        <th>Description</th>
    </tr>
</thead>
<tr>
    <td>{firstname}</td>
    <td>First Name</td>
</tr>
<tr>
    <td>{lastname}</td>
    <td>Last Name</td>
</tr>
<tr>
    <td>{date}</td>
    <td>Date Ordered</td>
</tr>
<tr>
    <td>{total}</td>
    <td>Total Amount</td>
</tr>
<tr>
    <td>{order_number}</td>
    <td>Order Number</td>
</tr>
<tr>
    <td>{order_complete_url}</td>
    <td>Order Complete URL</td>
</tr>
<tr>
    <td>{table}</td>
    <td>Table order detail</td>
</tr>
</table>