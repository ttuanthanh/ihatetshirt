<h5 class="sbold">Shortcodes :</h5>

<table class="table table-bordered">
<thead>
    <tr>
        <th>Code</th>
        <th>Description</th>
    </tr>
</thead>
<tr>
    <td>{firstname}</td>
    <td>First Name</td>
</tr>
<tr>
    <td>{lastname}</td>
    <td>Last Name</td>
</tr>
<tr>
    <td>{email}</td>
    <td>Email Address</td>
</tr>
<tr>
    <td>{password}</td>
    <td>Password</td>
</tr>
<tr>
    <td>{date}</td>
    <td>Register date</td>
</tr>
<tr>
    <td>{confirm_url}</td>
    <td>Confirm url</td>
</tr>
</table>