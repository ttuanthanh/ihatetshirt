<h5 class="sbold">Shortcodes :</h5>

<table class="table table-bordered">
<thead>
    <tr>
        <th>Code</th>
        <th>Description</th>
    </tr>
</thead>
<tr>
    <td>{url_design}</td>
    <td>Link of design</td>
</tr>
</table>