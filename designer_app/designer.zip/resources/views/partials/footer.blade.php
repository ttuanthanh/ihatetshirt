<div class="page-footer grade">
    <div class="page-footer-inner"> {{ date('Y') }} &copy; {{ App\Setting::get_setting('copy_right') }}
    </div>
    <div class="scroll-to-top">
        <i class="icon-arrow-up"></i>
    </div>
</div>

