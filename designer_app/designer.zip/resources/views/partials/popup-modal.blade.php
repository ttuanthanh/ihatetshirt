<div class="modal fade popup-modal" id="popupModal"  tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" data-backdrop="static" aria-hidden="false">
  <div class="modal-dialog">
    <div class="modal-content">
        <div class="modal-header">
            <button aria-hidden="true" data-dismiss="modal" class="close" type="button">&times;</button>
            <h4 class="modal-title">Title goes here ...</h4>
        </div>
        <div class="modal-body">
        Loading content body ..        
        </div>

        <div class="modal-footer">
        <a class="btn btn-primary confirm uppercase" data-href="#" data-index="" data-id="" data-target=""><i class="fa fa-check"></i> Confirm</a>
        <button class="btn btn-default uppercase" aria-hidden="true" data-dismiss="modal" class="close" type="button">Close</button> 
        <span class="msg"></span>           
        </div>
       
    </div>
  </div>
</div>

<div class="modal fade" id="img-preview">
    <div class="modal-dialog modal-smx">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                <h5 class="modal-title"></h5>
            </div>
            <div class="modal-body"><img src="" width="100%"></div>
        </div>
    </div>
</div>